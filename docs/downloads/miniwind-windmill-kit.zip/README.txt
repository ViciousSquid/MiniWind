MiniWind / Fio windmill asset kit

INSTALL
Copy assets/ and maps/ into your Fio project root, keeping the folder layout.
The OBJ and GLB share the brick texture. Retain the sidecar PNG.

MODELS
assets/models/windmill.glb
assets/models/windmill.obj + windmill.mtl + windmill_brick_albedo.png
Both are Y-up, with a ground-center origin, scale [1,1,1], rotation [0,0,0].
Overall height: 842.74 units. Foundation diameter: 288 units.
Door height: 106 units for a 100-unit player. About 3,240 triangles.

TRANSPARENT SPRITES
assets/sprites/scenery/windmill_topdown.png — true 90-degree overhead;
  Prop sprite_size [720,720], ground anchor at canvas center.
assets/sprites/scenery/windmill_overhead.png — 60-degree overhead;
  Prop sprite_size [860,860], ground anchor at canvas center.
assets/sprites/scenery/windmill_fantasy_topdown.png — fantasy overhead artwork.
assets/sprites/scenery/windmill_fantasy_overhead.png — angled fantasy artwork.

TRY THEM
Open maps/Windmill_Comparison.json in Fio. Left to right: GLB, OBJ,
true overhead sprite, angled overhead sprite. Raise the overhead camera
above the 843-unit sail tips when viewing the complete 3D model.

EDIT / REBUILD
assets/models/windmill.blend is the editable Blender source with
packed texture, rotor pivot, cameras, lighting and a hidden 100-unit figure.
game/tools/make_windmill.py regenerates the basic model and rendered sprites.
From this kit's root:
  blender -b -t 4 -P game/tools/make_windmill.py -- --samples 96
The fantasy images are separate generated artwork, not renders of the mesh.

More details: docs/windmill-assets.md
Previews: docs/screenshots/windmill-model.png and windmill-scale.png
Validated in Fio's own OBJ/GLB loaders and OpenGL renderer; 31 tests pass.
